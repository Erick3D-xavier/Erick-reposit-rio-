
// JavaScript pode ser adicionado aqui no futuro
console.log('Portfólio carregado com sucesso!');
